<?php

namespace Setcooki\Wp\Api\Retry;

/**
 * Class Exception
 * @package Setcooki\Wp\Api\Retry
 */
class Exception extends \ErrorException
{
}