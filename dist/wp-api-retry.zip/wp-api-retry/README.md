# wp-api-retry

Wordpress Plugin for queueing and retrying failed external api calls